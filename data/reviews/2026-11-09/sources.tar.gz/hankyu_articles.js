/**
 * 記事一覧表示の共通ライブラリ
 * news、release、blogで共通の機能を提供
 */
class ArticleManager {
  /**
   * @param {Object} config - 設定オブジェクト
   * @param {string} config.jsonPath - JSONデータのパス
   * @param {number} config.itemsPerPage - 1ページあたりのアイテム数
   * @param {number} [config.maxPagerButtons=5] - 最大ページボタン数
   * @param {Object} config.selectors - DOMセレクター
   * @param {string} config.selectors.container - 一覧コンテナのセレクター
   * @param {string} config.selectors.pagerArea - ページネーション領域のセレクター
   * @param {string} config.selectors.scrollTarget - スクロール先のセレクター
   * @param {Function} config.renderItems - アイテム一覧を描画する関数
   * @param {Function} config.setupFilters - フィルターを設定する関数
   * @param {Object} [config.initialFilters] - 初期フィルター
   * @param {Object} [config.jsonLd] - JSON-LD設定
   * @param {boolean} [config.jsonLd.enabled=false] - JSON-LDを有効にするか
   * @param {number} [config.jsonLd.maxItems=10] - JSON-LDに含める最大アイテム数
   * @param {Function} [config.jsonLd.generator] - JSON-LD生成関数
   */
  constructor(config) {
    this.config = {
      maxPagerButtons: 5,
      initialFilters: {},
      jsonLd: {
        enabled: false,
        maxItems: 10,
      },
      ...config
    };

    // 状態管理
    this.state = {
      allItems: [],
      filteredItems: [],
      currentPage: 1,
      filters: { ...this.config.initialFilters }
    };
  }

  /**
   * 初期化処理
   */
  async init() {
    try {
      await this.loadData();
      
      // 初期フィルターを適用
      if (this.config.initialFilters) {
        this.state.filters = { ...this.config.initialFilters };
      }
      
      // フィルターイベントリスナーを設定
      if (this.config.setupFilters) {
        this.config.setupFilters(this);
      }
      
      // 初期表示
      this.applyFilters();
      
      // JSON-LD注入
      if (this.config.jsonLd.enabled && this.config.jsonLd.generator) {
        this.injectJsonLd(this.state.allItems);
      }
    } catch (error) {
      this.showError();
    }
  }

  /**
   * JSONデータを読み込む
   */
  async loadData() {
    const response = await fetch(this.config.jsonPath + '?_t=' + new Date().getTime());
    if (!response.ok) {
      throw new Error('Failed to load data');
    }
    const data = await response.json();
    this.state.allItems = data;
    this.state.filteredItems = data;
  }

  /**
   * フィルターを適用
   */
  applyFilters() {
    // カスタムフィルター処理がある場合はそれを使用
    if (this.config.applyFilters) {
      this.state.filteredItems = this.config.applyFilters(this.state.allItems, this.state.filters);
    } else {
      // デフォルトのフィルター処理
      this.state.filteredItems = this.state.allItems.filter(item => {
        let match = true;
        
        // カテゴリーフィルター
        if (this.state.filters.category) {
          match = match && (item.category === this.state.filters.category);
        }
        
        // 年フィルター
        if (this.state.filters.year) {
          match = match && (item.year === this.state.filters.year);
        }
        
        return match;
      });
    }

    // ページを1に戻す
    this.state.currentPage = 1;

    // カスタム更新処理（見出しの更新など）
    if (this.config.onFilterApplied) {
      this.config.onFilterApplied(this);
    }

    // 再描画
    this.render();
    
    // スクロール
    this.scrollToTop();
  }

  /**
   * 一覧とページネーションを描画
   */
  render() {
    this.renderItems();
    this.renderPagination();
  }
  
  /**
   * アイテム一覧を描画（カスタム関数を呼び出し）
   */
  renderItems() {
    const start = (this.state.currentPage - 1) * this.config.itemsPerPage;
    const end = start + this.config.itemsPerPage;
    const itemsToShow = this.state.filteredItems.slice(start, end);

    if (this.config.renderItems) {
      this.config.renderItems(itemsToShow, this.state.filteredItems.length);
    }
  }

  /**
   * ページネーションを描画
   */
  renderPagination() {
    const pagerElement = document.querySelector(this.config.selectors.pagerArea + ' .pager');
    if (!pagerElement) return;

    const totalPages = Math.ceil(this.state.filteredItems.length / this.config.itemsPerPage);

    // ページネーションをクリア
    pagerElement.innerHTML = '';

    const pagerArea = document.querySelector(this.config.selectors.pagerArea);
    if (!pagerArea) return;

    if (totalPages <= 1) {
      // 1ページ以下の場合はページネーションを非表示
      pagerArea.style.display = 'none';
      return;
    }

    pagerArea.style.display = '';

    // DocumentFragmentを使用してDOM操作を最適化
    const fragment = document.createDocumentFragment();

    // ページ番号の範囲を計算
    let startPage = Math.max(1, this.state.currentPage - Math.floor(this.config.maxPagerButtons / 2));
    let endPage = Math.min(totalPages, startPage + this.config.maxPagerButtons - 1);

    // 調整
    if (endPage - startPage < this.config.maxPagerButtons - 1) {
      startPage = Math.max(1, endPage - this.config.maxPagerButtons + 1);
    }

    // 最初のページ
    if (startPage > 1) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = '1';
      a.dataset.page = '1';
      li.appendChild(a);
      fragment.appendChild(li);

      if (startPage > 2) {
        const liDots = document.createElement('li');
        const span = document.createElement('span');
        span.textContent = '…';
        liDots.appendChild(span);
        fragment.appendChild(liDots);
      }
    }

    // ページ番号
    for (let i = startPage; i <= endPage; i++) {
      const li = document.createElement('li');
      if (i === this.state.currentPage) {
        li.className = 'active';
      }

      const a = document.createElement('a');
      a.href = '#';
      a.textContent = i;
      a.dataset.page = i;

      li.appendChild(a);
      fragment.appendChild(li);
    }

    // 最後のページ
    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        const liDots = document.createElement('li');
        const span = document.createElement('span');
        span.textContent = '…';
        liDots.appendChild(span);
        fragment.appendChild(liDots);
      }

      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = '#';
      a.textContent = totalPages;
      a.dataset.page = totalPages;
      li.appendChild(a);
      fragment.appendChild(li);
    }

    // 一度にDOMに追加
    pagerElement.appendChild(fragment);

    // ページ番号ボタンにイベントリスナーを設定
    this.setupPaginationListeners();
  }

  /**
   * ページ切り替え処理
   */
  changePage(newPage) {
    if (newPage !== this.state.currentPage) {
      this.state.currentPage = newPage;
      this.renderItems();
      this.renderPagination();
      this.scrollToTop();
    }
  }

  /**
   * ページネーションボタンのイベントリスナーを設定
   */
  setupPaginationListeners() {
    const pagerArea = document.querySelector(this.config.selectors.pagerArea);
    if (!pagerArea) return;

    const totalPages = Math.ceil(this.state.filteredItems.length / this.config.itemsPerPage);

    // 前へボタン
    const prevButton = pagerArea.querySelector('.prev a');
    if (prevButton) {
      const newPrevButton = prevButton.cloneNode(true);
      prevButton.parentNode.replaceChild(newPrevButton, prevButton);
      newPrevButton.addEventListener('click', (e) => {
        e.preventDefault();
        if (this.state.currentPage > 1) {
          this.changePage(this.state.currentPage - 1);
        }
      });
    }

    // 次へボタン
    const nextButton = pagerArea.querySelector('.next a');
    if (nextButton) {
      const newNextButton = nextButton.cloneNode(true);
      nextButton.parentNode.replaceChild(newNextButton, nextButton);
      newNextButton.addEventListener('click', (e) => {
        e.preventDefault();
        if (this.state.currentPage < totalPages) {
          this.changePage(this.state.currentPage + 1);
        }
      });
    }

    // ページ番号ボタン
    pagerArea.querySelectorAll('.pager a').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = parseInt(link.dataset.page);
        if (page) {
          this.changePage(page);
        }
      });
    });
  }

  /**
   * ページトップにスクロール
   */
  scrollToTop() {
    // 少し遅延させて実行（レンダリング完了待ち）
    setTimeout(() => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }, 10);
  }

  /**
   * JSON-LDを注入
   */
  injectJsonLd(items) {
    if (this.config.jsonLd.generator) {
      const structuredData = this.config.jsonLd.generator(
        items.slice(0, this.config.jsonLd.maxItems)
      );

      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify(structuredData, null, 2);
      document.head.appendChild(script);
    }
  }

  /**
   * エラー表示（カスタム関数または デフォルト）
   */
  showError() {
    if (this.config.showError) {
      this.config.showError();
    } else {
      // デフォルトのエラー表示
      const container = document.querySelector(this.config.selectors.container);
      if (container) {
        container.innerHTML = '<p style="padding: 2em; text-align: center; color: #d00;">データの読み込みに失敗しました。しばらくしてから再度お試しください。</p>';
      }

      const pagerArea = document.querySelector(this.config.selectors.pagerArea);
      if (pagerArea) {
        pagerArea.style.display = 'none';
      }
    }
  }
}

/**
 * ページ別プリセット定義
 */
ArticleManager.presets = {
  /**
   * ニュース用プリセット
   */
  news: {
    jsonPath: '/news/news-data.json',
    itemsPerPage: 10,
    maxPagerButtons: 5,

    selectors: {
      container: '.newsList',
      pagerArea: '.pagerArea',
      scrollTarget: '.newsHead'
    },

    renderItems: function(newsToShow, totalCount) {
      const newsListElement = document.querySelector('.newsList');
      if (!newsListElement) return;

      newsListElement.innerHTML = '';

      if (newsToShow.length === 0) {
        const noData = document.createElement('p');
        noData.className = 'no-data-message';
        noData.textContent = '該当するお知らせはありません。';
        newsListElement.appendChild(noData);
        return;
      }

      const fragment = document.createDocumentFragment();

      newsToShow.forEach(news => {
        const dt = document.createElement('dt');
        dt.textContent = news.category;

        const ddDay = document.createElement('dd');
        ddDay.className = 'day';
        ddDay.textContent = news.date;

        const ddTitle = document.createElement('dd');
        ddTitle.className = 'title';

        const link = document.createElement('a');

        if (ArticleManager.helpers.isSafeUrl(news.url)) {
          link.href = news.url;
          if (news.url.toLowerCase().endsWith('.pdf')) {
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
          }
        } else {
          link.href = '#';
        }

        link.textContent = news.title;

        ddTitle.appendChild(link);

        fragment.appendChild(dt);
        fragment.appendChild(ddDay);
        fragment.appendChild(ddTitle);
      });

      newsListElement.appendChild(fragment);
    },

    setupFilters: function(manager) {
      const categoryLinks = document.querySelectorAll('.sideMenu .btnStyle dd a');

      ArticleManager.helpers.updateYearOptions(manager);

      categoryLinks.forEach(link => {
        link.addEventListener('click', (e) => {
          e.preventDefault();
          const category = link.querySelector('span').textContent;

          if (manager.state.filters.category === category) {
            manager.state.filters.category = null;
            link.style.backgroundColor = '';
          } else {
            categoryLinks.forEach(l => l.style.backgroundColor = '');
            manager.state.filters.category = category;
            link.style.backgroundColor = '#e0e0e0';
          }

          manager.applyFilters();
        });
      });

      const filterButton = document.querySelector('.sideMenu .btnStyle button');
      if (filterButton) {
        filterButton.addEventListener('click', (e) => {
          e.preventDefault();
          const yearSelect = document.querySelector('.sideMenu .btnStyle select[name="arcive"]');
          if (yearSelect?.value) {
            manager.state.filters.year = parseInt(yearSelect.value);
          }
          manager.applyFilters();
        });
      }
    },

    onFilterApplied: function(manager) {
      ArticleManager.helpers.updateNewsHeadTitle(manager);
    },

    jsonLd: {
      enabled: true,
      maxItems: 20,
      generator: function(newsList) {
        return {
          '@context': 'https://schema.org',
          '@type': 'ItemList',
          'itemListElement': newsList.map((news, index) => ({
            '@type': 'ListItem',
            'position': index + 1,
            'item': {
              '@type': 'NewsArticle',
              'headline': news.title,
              'url': new URL(news.url, window.location.href).href,
              'datePublished': news.date,
              'author': {
                '@type': 'Organization',
                'name': '阪急バス株式会社'
              }
            }
          }))
        };
      }
    },

    showError: function() {
      const newsListElement = document.querySelector('.newsList');
      if (newsListElement) {
        const errorMsg = document.createElement('p');
        errorMsg.className = 'error-message';
        errorMsg.textContent = 'お知らせの読み込みに失敗しました。しばらくしてから再度お試しください。';
        newsListElement.innerHTML = '';
        newsListElement.appendChild(errorMsg);
      }

      const pagerArea = document.querySelector('.pagerArea');
      if (pagerArea) {
        pagerArea.style.display = 'none';
      }
    }
  },

  /**
   * リリース用プリセット
   */
  release: {
    jsonPath: '/release/release-data.json',
    itemsPerPage: 10,
    maxPagerButtons: 5,

    selectors: {
      container: '.newsList',
      pagerArea: '.pagerArea',
      scrollTarget: '.newsHead'
    },

    scrollOffset: 130,

    renderItems: function(releasesToShow, totalCount) {
      const newsList = document.querySelector('.newsList');
      if (!newsList) return;

      newsList.innerHTML = '';

      const sideRead = document.querySelector('.sideRead');
      if (sideRead) {
        const existingNoDataMessage = sideRead.querySelector('p[class*="message"]');
        if (existingNoDataMessage) {
          existingNoDataMessage.remove();
        }
      }

      if (releasesToShow.length === 0) {
        const noData = document.createElement('p');
        noData.className = 'no-data-message';
        noData.textContent = '該当するリリースが見つかりませんでした。';
        if (sideRead) {
          sideRead.appendChild(noData);
        }
        return;
      }

      const fragment = document.createDocumentFragment();

      releasesToShow.forEach(release => {
        const dt = document.createElement('dt');
        dt.textContent = release.category;
        fragment.appendChild(dt);

        const ddDay = document.createElement('dd');
        ddDay.className = 'day';
        ddDay.textContent = release.date;
        fragment.appendChild(ddDay);

        const ddTitle = document.createElement('dd');
        ddTitle.className = 'title';
        const link = document.createElement('a');
        link.href = release.url;
        if (release.url.toLowerCase().endsWith('.pdf')) {
          link.target = '_blank';
          link.rel = 'noopener noreferrer';
        }
        link.textContent = release.title;
        ddTitle.appendChild(link);
        fragment.appendChild(ddTitle);
      });

      newsList.appendChild(fragment);
    },

    setupFilters: function(manager) {
      ArticleManager.helpers.updateYearOptions(manager);

      const filterButton = document.querySelector('.sideMenu .btnStyle button');
      const yearSelect = document.querySelector('.sideMenu .btnStyle select[name="arcive"]');

      if (filterButton && yearSelect) {
        filterButton.addEventListener('click', (e) => {
          e.preventDefault();

          const selectedYear = parseInt(yearSelect.value);
          if (selectedYear) {
            manager.state.filters.year = selectedYear;
            manager.applyFilters();
          }
        });
      }
    },

    onFilterApplied: function(manager) {
      ArticleManager.helpers.updateNewsHeadTitle(manager);
    },

    jsonLd: {
      enabled: true,
      maxItems: 10,
      generator: function(releaseList) {
        return {
          '@context': 'https://schema.org',
          '@type': 'ItemList',
          'itemListElement': releaseList.map((release, index) => ({
            '@type': 'ListItem',
            'position': index + 1,
            'item': {
              '@type': 'NewsArticle',
              'headline': release.title,
              'url': new URL(release.url, window.location.href).href,
              'datePublished': release.date.replace(/\./g, '-'),
              'author': {
                '@type': 'Organization',
                'name': '阪急バス株式会社'
              }
            }
          }))
        };
      }
    },

    showError: function() {
      const newsList = document.querySelector('.newsList');
      if (newsList) {
        newsList.innerHTML = '';
      }

      const sideRead = document.querySelector('.sideRead');
      if (sideRead) {
        const errorMessage = document.createElement('p');
        errorMessage.className = 'error-message';
        errorMessage.textContent = 'リリースデータの読み込みに失敗しました。しばらくしてから再度お試しください。';
        sideRead.appendChild(errorMessage);
      }

      const pagerArea = document.querySelector('.pagerArea');
      if (pagerArea) {
        pagerArea.style.display = 'none';
      }
    }
  },

  /**
   * ブログ用プリセット
   */
  blog: {
    jsonPath: '/blog/blog-data.json',
    itemsPerPage: 9,
    maxPagerButtons: 5,

    selectors: {
      container: '.blogArea',
      pagerArea: '.pagerArea',
      scrollTarget: '.blogTitle'
    },

    renderItems: function(blogsToShow, totalCount) {
      const blogArea = document.querySelector('.blogArea');
      if (!blogArea) return;

      const existingBlogs = blogArea.querySelectorAll('.blogList');
      existingBlogs.forEach(blog => blog.remove());

      const existingNoDataMessage = blogArea.querySelector('p[class*="message"]');
      if (existingNoDataMessage) {
        existingNoDataMessage.remove();
      }

      if (blogsToShow.length === 0) {
        const noData = document.createElement('p');
        noData.className = 'no-data-message';
        noData.textContent = '該当する記事が見つかりませんでした。';
        blogArea.insertBefore(noData, blogArea.querySelector('.blogCategory'));
        return;
      }

      if (blogsToShow.length > 0) {
        const firstBlogDiv = ArticleManager.helpers.createFirstBlogElement(blogsToShow[0]);
        blogArea.insertBefore(firstBlogDiv, blogArea.querySelector('.blogCategory'));
      }

      if (blogsToShow.length > 1) {
        const restBlogs = blogsToShow.slice(1);
        const blogListDiv = ArticleManager.helpers.createRestBlogsElement(restBlogs);
        blogArea.insertBefore(blogListDiv, blogArea.querySelector('.blogCategory'));
      }
    },

    setupFilters: function(manager) {
      const categoryLinks = document.querySelectorAll('.blogCategory dd a');

      categoryLinks.forEach(link => {
        link.addEventListener('click', (e) => {
          e.preventDefault();

          const categoryText = link.innerHTML
            .replace(/\<br\s*\/?\>/gi, ' ')
            .replace(/\<[^\>]+\>/g, '')
            .trim();

          if (manager.state.filters.category === categoryText) {
            manager.state.filters.category = null;
            categoryLinks.forEach(l => l.style.backgroundColor = '');
          } else {
            categoryLinks.forEach(l => l.style.backgroundColor = '');
            manager.state.filters.category = categoryText;
            link.style.backgroundColor = '#e0e0e0';
          }

          manager.applyFilters();
        });
      });
    },

    jsonLd: {
      enabled: true,
      maxItems: 9,
      generator: function(blogList) {
        return {
          '@context': 'https://schema.org',
          '@type': 'ItemList',
          'itemListElement': blogList.map((blog, index) => ({
            '@type': 'ListItem',
            'position': index + 1,
            'item': {
              '@type': 'BlogPosting',
              'headline': blog.title,
              'url': new URL(blog.url, window.location.href).href,
              'datePublished': blog.date.replace(/\./g, '-'),
              'image': blog.image.startsWith('http') ? blog.image : new URL(blog.image, window.location.href).href,
              'author': {
                '@type': 'Organization',
                'name': '阪急バス株式会社'
              }
            }
          }))
        };
      }
    },

    showError: function() {
      const blogArea = document.querySelector('.blogArea');
      if (blogArea) {
        const existingBlogs = blogArea.querySelectorAll('.blogList');
        existingBlogs.forEach(blog => blog.remove());

        const errorMessage = document.createElement('p');
        errorMessage.className = 'error-message';
        errorMessage.textContent = 'ブログデータの読み込みに失敗しました。しばらくしてから再度お試しください。';
        blogArea.insertBefore(errorMessage, blogArea.querySelector('.blogCategory'));
      }

      const pagerArea = document.querySelector('.pagerArea');
      if (pagerArea) {
        pagerArea.style.display = 'none';
      }
    }
  }
};

/**
 * ヘルパー関数
 */
ArticleManager.helpers = {
  /**
   * URLが安全かどうかを検証
   */
  isSafeUrl: function(url) {
    if (!url || typeof url !== 'string') return false;

    const dangerousProtocols = /^(javascript|data|vbscript|file):/i;
    if (dangerousProtocols.test(url.trim())) {
      return false;
    }

    const safeProtocols = /^(https?:\/\/|\/)/i;
    return safeProtocols.test(url.trim()) || !url.includes(':');
  },

  /**
   * ニュース見出しの年代を更新
   */
  updateNewsHeadTitle: function(manager) {
    const newsHead = document.querySelector('.newsHead');
    if (!newsHead || !manager.state.filters.year) return;

    newsHead.textContent = `${manager.state.filters.year}年 一覧`;
  },

  /**
   * 年代セレクトボックスのオプションを更新
   */
  updateYearOptions: function(manager) {
    const yearSelect = document.querySelector('.sideMenu .btnStyle select[name="arcive"]');
    if (!yearSelect) return;

    const years = [...new Set(manager.state.allItems.map(item => item.year))].sort((a, b) => b - a);

    yearSelect.innerHTML = '';

    years.forEach(year => {
      const option = document.createElement('option');
      option.value = year;
      option.textContent = year + '年';
      yearSelect.appendChild(option);
    });

    if (years.length > 0 && manager.state.filters.year) {
      yearSelect.value = manager.state.filters.year;
    }
  },

  /**
   * 初期年フィルターを設定
   */
  getInitialYear: function(data) {
    if (data && data.length > 0) {
      return data[0].year;
    }
    return new Date().getFullYear();
  },

  /**
   * 1件目のブログ要素を作成
   */
  createFirstBlogElement: function(blog) {
    const blogDiv = document.createElement('div');
    blogDiv.className = 'blogList first-info';

    const link = document.createElement('a');
    link.href = blog.url;

    const imgBox = document.createElement('div');
    imgBox.className = 'imgBox';
    const img = document.createElement('img');
    img.src = blog.image;
    img.width = '100%';
    img.height = '100%';
    img.alt = blog.title;
    img.decoding = 'async';
    imgBox.appendChild(img);
    link.appendChild(imgBox);

    const readDiv = document.createElement('div');
    readDiv.className = 'read';

    const dl = document.createElement('dl');
    const dt = document.createElement('dt');
    dt.textContent = blog.category;
    const dd = document.createElement('dd');
    dd.textContent = blog.date;
    dl.appendChild(dt);
    dl.appendChild(dd);
    readDiv.appendChild(dl);

    const h2 = document.createElement('h2');
    h2.textContent = blog.title;
    readDiv.appendChild(h2);

    if (blog.excerpt) {
      const p = document.createElement('p');
      p.textContent = blog.excerpt;
      readDiv.appendChild(p);
    }

    link.appendChild(readDiv);
    blogDiv.appendChild(link);

    return blogDiv;
  },

  /**
   * 2件目以降のブログ要素を作成
   */
  createRestBlogsElement: function(blogs) {
    const blogDiv = document.createElement('div');
    blogDiv.className = 'blogList';

    blogs.forEach(blog => {
      const link = document.createElement('a');
      link.href = blog.url;

      const imgBox = document.createElement('div');
      imgBox.className = 'imgBox';
      const img = document.createElement('img');
      img.src = blog.image;
      img.width = '100%';
      img.height = '100%';
      img.alt = blog.title;
      img.decoding = 'async';
      imgBox.appendChild(img);
      link.appendChild(imgBox);

      const readDiv = document.createElement('div');
      readDiv.className = 'read';

      const dl = document.createElement('dl');
      const dt = document.createElement('dt');
      dt.textContent = blog.category;
      const dd = document.createElement('dd');
      dd.textContent = blog.date;
      dl.appendChild(dt);
      dl.appendChild(dd);
      readDiv.appendChild(dl);

      const h2 = document.createElement('h2');
      h2.textContent = blog.title;
      readDiv.appendChild(h2);

      link.appendChild(readDiv);
      blogDiv.appendChild(link);
    });

    return blogDiv;
  }
};

/**
 * プリセットからインスタンスを作成
 */
ArticleManager.createFromPreset = function(presetName, customConfig) {
  const preset = ArticleManager.presets[presetName];
  if (!preset) {
    throw new Error(`Preset "${presetName}" not found`);
  }

  const config = customConfig ? { ...preset, ...customConfig } : preset;
  return new ArticleManager(config);
};

/**
 * news専用の初期化（データロード後に最新年を設定）
 */
ArticleManager.initNews = async function() {
  const manager = ArticleManager.createFromPreset('news');

  try {
    await manager.loadData();

    manager.state.filters.year = ArticleManager.helpers.getInitialYear(manager.state.allItems);

    if (manager.config.setupFilters) {
      manager.config.setupFilters(manager);
    }

    manager.applyFilters();

    if (manager.config.jsonLd.enabled && manager.config.jsonLd.generator) {
      manager.injectJsonLd(manager.state.allItems);
    }
  } catch (error) {
    manager.showError();
  }

  return manager;
};

/**
 * release専用の初期化（データロード後に最新年を設定）
 */
ArticleManager.initRelease = async function() {
  const manager = ArticleManager.createFromPreset('release');

  try {
    await manager.loadData();

    manager.state.filters.year = ArticleManager.helpers.getInitialYear(manager.state.allItems);

    if (manager.config.setupFilters) {
      manager.config.setupFilters(manager);
    }

    manager.applyFilters();

    if (manager.config.jsonLd.enabled && manager.config.jsonLd.generator) {
      manager.injectJsonLd(manager.state.allItems);
    }
  } catch (error) {
    manager.showError();
  }

  return manager;
};

/**
 * 自動初期化
 * URLパスやDOM要素から自動的にページタイプを判定して初期化
 */
(function() {
  'use strict';

  function autoInit() {
    const path = window.location.pathname;

    // URLパスからページタイプを判定
    if (path.includes('/news/')) {
      // ニュースページ
      if (document.querySelector('.newsList')) {
        ArticleManager.initNews();
      }
    } else if (path.includes('/release/')) {
      // リリースページ
      if (document.querySelector('.newsList')) {
        ArticleManager.initRelease();
      }
    } else if (path.includes('/blog/')) {
      // ブログページ
      if (document.querySelector('.blogArea')) {
        const blogManager = ArticleManager.createFromPreset('blog');
        blogManager.init();
      }
    }
  }

  // DOMContentLoaded後に自動初期化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInit);
  } else {
    autoInit();
  }
})();
